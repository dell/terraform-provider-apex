# ErrorMessage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **string** |  | [optional] 
**Timestamp** | [**time.Time**](time.Time.md) |  | [optional] 
**Severity** | [**ErrorMessageSeverityEnum**](ErrorMessageSeverityEnum.md) |  | [optional] 
**Message** | **string** |  | [optional] 
**MessageL10n** | **string** |  | [optional] 
**SubstitutionArgs** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


