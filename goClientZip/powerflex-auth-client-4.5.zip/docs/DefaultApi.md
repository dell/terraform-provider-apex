# \DefaultApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PostRestAuthLogin**](DefaultApi.md#PostRestAuthLogin) | **Post** /rest/auth/login | login
[**PostRestAuthLogout**](DefaultApi.md#PostRestAuthLogout) | **Post** /rest/auth/logout | logout from application
[**PostRestAuthUpdateToken**](DefaultApi.md#PostRestAuthUpdateToken) | **Post** /rest/auth/update-token | update token



## PostRestAuthLogin

> LoginResponseYaml PostRestAuthLogin(ctx, optional)

login

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***PostRestAuthLoginOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a PostRestAuthLoginOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loginCredentialsYaml** | [**optional.Interface of LoginCredentialsYaml**](LoginCredentialsYaml.md)|  | 

### Return type

[**LoginResponseYaml**](login-response.yaml.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## PostRestAuthLogout

> PostRestAuthLogout(ctx, authorization, optional)

logout from application

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**authorization** | **string**| A valid JWT Token | 
 **optional** | ***PostRestAuthLogoutOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a PostRestAuthLogoutOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **accept** | **optional.String**|  | 
 **contentType** | **optional.String**|  | 
 **logoutRequestYaml** | [**optional.Interface of LogoutRequestYaml**](LogoutRequestYaml.md)|  | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## PostRestAuthUpdateToken

> LoginResponseYaml PostRestAuthUpdateToken(ctx, contentType, optional)

update token

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**contentType** | **string**|  | 
 **optional** | ***PostRestAuthUpdateTokenOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a PostRestAuthUpdateTokenOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **accept** | **optional.String**|  | 
 **updateTokenRequestYaml** | [**optional.Interface of UpdateTokenRequestYaml**](UpdateTokenRequestYaml.md)|  | 

### Return type

[**LoginResponseYaml**](login-response.yaml.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

