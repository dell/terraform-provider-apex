# LoginResponseYaml

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessToken** | **string** |  | [optional] 
**ExpiresIn** | **int64** |  | [optional] 
**RefreshExpiresIn** | **int64** |  | [optional] 
**RefreshToken** | **string** |  | [optional] 
**TokenType** | **string** |  | [optional] 
**IdToken** | **string** |  | [optional] 
**SessionState** | **string** |  | [optional] 
**Scope** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


