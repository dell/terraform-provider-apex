# \DefaultApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PostRestAuthLogin**](DefaultApi.md#PostRestAuthLogin) | **Post** /session/1/session | login



## PostRestAuthLogin

> PostRestAuthLogin(ctx, optional)

login

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***PostRestAuthLoginOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a PostRestAuthLoginOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loginCredentialsYaml** | [**optional.Interface of LoginCredentialsYaml**](LoginCredentialsYaml.md)|  | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

