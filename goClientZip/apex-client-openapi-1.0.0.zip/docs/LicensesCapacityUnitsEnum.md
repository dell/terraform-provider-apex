# LicensesCapacityUnitsEnum

## Enum


* `COUNT` (value: `"COUNT"`)

* `PERCENT` (value: `"PERCENT"`)

* `REQUEST_P_MIN` (value: `"REQUEST_P_MIN"`)

* `BYTE` (value: `"BYTE"`)

* `BYTE_P_SEC` (value: `"BYTE_P_SEC"`)

* `IO_P_SEC` (value: `"IO_P_SEC"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


