# AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IamAWSServiceName** | Pointer to **[]string** |  | [optional] 

## Methods

### NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike

`func NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike() *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike`

NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike instantiates a new AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLikeWithDefaults

`func NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLikeWithDefaults() *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike`

NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLikeWithDefaults instantiates a new AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIamAWSServiceName

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike) GetIamAWSServiceName() []string`

GetIamAWSServiceName returns the IamAWSServiceName field if non-nil, zero value otherwise.

### GetIamAWSServiceNameOk

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike) GetIamAWSServiceNameOk() (*[]string, bool)`

GetIamAWSServiceNameOk returns a tuple with the IamAWSServiceName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIamAWSServiceName

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike) SetIamAWSServiceName(v []string)`

SetIamAWSServiceName sets IamAWSServiceName field to given value.

### HasIamAWSServiceName

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike) HasIamAWSServiceName() bool`

HasIamAWSServiceName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


