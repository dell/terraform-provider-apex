# HTTPStatusEnum

## Enum


* `_200` (value: `200`)

* `_201` (value: `201`)

* `_202` (value: `202`)

* `_204` (value: `204`)

* `_206` (value: `206`)

* `_299` (value: `299`)

* `_400` (value: `400`)

* `_401` (value: `401`)

* `_403` (value: `403`)

* `_404` (value: `404`)

* `_422` (value: `422`)

* `_429` (value: `429`)

* `_500` (value: `500`)

* `_503` (value: `503`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


