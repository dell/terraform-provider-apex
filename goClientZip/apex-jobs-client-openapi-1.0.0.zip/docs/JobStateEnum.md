# JobStateEnum

## Enum


* `SCHEDULED` (value: `"SCHEDULED"`)

* `QUEUED` (value: `"QUEUED"`)

* `RUNNING` (value: `"RUNNING"`)

* `PAUSING` (value: `"PAUSING"`)

* `PAUSED` (value: `"PAUSED"`)

* `RESUMING` (value: `"RESUMING"`)

* `CANCELLING` (value: `"CANCELLING"`)

* `CANCELLED` (value: `"CANCELLED"`)

* `SUCCEEDED` (value: `"SUCCEEDED"`)

* `COMPLETED_WITH_MESSAGES` (value: `"COMPLETED_WITH_MESSAGES"`)

* `FAILED` (value: `"FAILED"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


