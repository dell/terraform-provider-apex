# DeploymentDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeploymentType** | Pointer to [**SystemDeploymentTypeEnum**](SystemDeploymentTypeEnum.md) |  | [optional] [default to ONPREM]
**CloudType** | Pointer to [**CloudProviderEnum**](CloudProviderEnum.md) |  | [optional] [default to AWS]
**CloudAccount** | Pointer to **string** | Cloud provider account where the storage system resides. | [optional] 
**CloudRegion** | Pointer to **string** | Cloud provider region where the storage system resides. | [optional] 
**AvailabilityZoneTopology** | Pointer to [**AvailabilityZoneTopologyEnum**](AvailabilityZoneTopologyEnum.md) |  | [optional] 
**VirtualPrivateCloud** | Pointer to **string** | Cloud virtual private environment identifier. | [optional] 
**CloudManagementAddress** | Pointer to **string** | Management IPv4 or IPv6 address or DNS name of the storage system in cloud. | [optional] 
**MinimumIops** | Pointer to **int64** | Minimum IOPS requested during the deployment time - Unit: IO/s | [optional] 
**MinimumCapacity** | Pointer to **int64** | Minimum capacity requested during the deployment time - Unit: bytes | [optional] 
**TierType** | Pointer to **string** | Tier type requested during the deployment time. | [optional] 
**SiteName** | Pointer to **string** | Name of the site where the system is located. | [optional] 
**Location** | Pointer to **string** | User provided description of where the system is located. | [optional] 
**Country** | Pointer to **string** | Name of the country where the system is located. | [optional] 
**State** | Pointer to **string** | Name of the state where the system is located. | [optional] 
**City** | Pointer to **string** | Name of the city where the system is located. | [optional] 
**StreetAddress1** | Pointer to **string** | Street address 1 of where the system is located. | [optional] 
**StreetAddress2** | Pointer to **string** | Street address 2 of where the system is located. | [optional] 
**ZipCode** | Pointer to **string** | State ZIP code of where the system is located. | [optional] 

## Methods

### NewDeploymentDetails

`func NewDeploymentDetails() *DeploymentDetails`

NewDeploymentDetails instantiates a new DeploymentDetails object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDeploymentDetailsWithDefaults

`func NewDeploymentDetailsWithDefaults() *DeploymentDetails`

NewDeploymentDetailsWithDefaults instantiates a new DeploymentDetails object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDeploymentType

`func (o *DeploymentDetails) GetDeploymentType() SystemDeploymentTypeEnum`

GetDeploymentType returns the DeploymentType field if non-nil, zero value otherwise.

### GetDeploymentTypeOk

`func (o *DeploymentDetails) GetDeploymentTypeOk() (*SystemDeploymentTypeEnum, bool)`

GetDeploymentTypeOk returns a tuple with the DeploymentType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeploymentType

`func (o *DeploymentDetails) SetDeploymentType(v SystemDeploymentTypeEnum)`

SetDeploymentType sets DeploymentType field to given value.

### HasDeploymentType

`func (o *DeploymentDetails) HasDeploymentType() bool`

HasDeploymentType returns a boolean if a field has been set.

### GetCloudType

`func (o *DeploymentDetails) GetCloudType() CloudProviderEnum`

GetCloudType returns the CloudType field if non-nil, zero value otherwise.

### GetCloudTypeOk

`func (o *DeploymentDetails) GetCloudTypeOk() (*CloudProviderEnum, bool)`

GetCloudTypeOk returns a tuple with the CloudType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudType

`func (o *DeploymentDetails) SetCloudType(v CloudProviderEnum)`

SetCloudType sets CloudType field to given value.

### HasCloudType

`func (o *DeploymentDetails) HasCloudType() bool`

HasCloudType returns a boolean if a field has been set.

### GetCloudAccount

`func (o *DeploymentDetails) GetCloudAccount() string`

GetCloudAccount returns the CloudAccount field if non-nil, zero value otherwise.

### GetCloudAccountOk

`func (o *DeploymentDetails) GetCloudAccountOk() (*string, bool)`

GetCloudAccountOk returns a tuple with the CloudAccount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudAccount

`func (o *DeploymentDetails) SetCloudAccount(v string)`

SetCloudAccount sets CloudAccount field to given value.

### HasCloudAccount

`func (o *DeploymentDetails) HasCloudAccount() bool`

HasCloudAccount returns a boolean if a field has been set.

### GetCloudRegion

`func (o *DeploymentDetails) GetCloudRegion() string`

GetCloudRegion returns the CloudRegion field if non-nil, zero value otherwise.

### GetCloudRegionOk

`func (o *DeploymentDetails) GetCloudRegionOk() (*string, bool)`

GetCloudRegionOk returns a tuple with the CloudRegion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudRegion

`func (o *DeploymentDetails) SetCloudRegion(v string)`

SetCloudRegion sets CloudRegion field to given value.

### HasCloudRegion

`func (o *DeploymentDetails) HasCloudRegion() bool`

HasCloudRegion returns a boolean if a field has been set.

### GetAvailabilityZoneTopology

`func (o *DeploymentDetails) GetAvailabilityZoneTopology() AvailabilityZoneTopologyEnum`

GetAvailabilityZoneTopology returns the AvailabilityZoneTopology field if non-nil, zero value otherwise.

### GetAvailabilityZoneTopologyOk

`func (o *DeploymentDetails) GetAvailabilityZoneTopologyOk() (*AvailabilityZoneTopologyEnum, bool)`

GetAvailabilityZoneTopologyOk returns a tuple with the AvailabilityZoneTopology field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvailabilityZoneTopology

`func (o *DeploymentDetails) SetAvailabilityZoneTopology(v AvailabilityZoneTopologyEnum)`

SetAvailabilityZoneTopology sets AvailabilityZoneTopology field to given value.

### HasAvailabilityZoneTopology

`func (o *DeploymentDetails) HasAvailabilityZoneTopology() bool`

HasAvailabilityZoneTopology returns a boolean if a field has been set.

### GetVirtualPrivateCloud

`func (o *DeploymentDetails) GetVirtualPrivateCloud() string`

GetVirtualPrivateCloud returns the VirtualPrivateCloud field if non-nil, zero value otherwise.

### GetVirtualPrivateCloudOk

`func (o *DeploymentDetails) GetVirtualPrivateCloudOk() (*string, bool)`

GetVirtualPrivateCloudOk returns a tuple with the VirtualPrivateCloud field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVirtualPrivateCloud

`func (o *DeploymentDetails) SetVirtualPrivateCloud(v string)`

SetVirtualPrivateCloud sets VirtualPrivateCloud field to given value.

### HasVirtualPrivateCloud

`func (o *DeploymentDetails) HasVirtualPrivateCloud() bool`

HasVirtualPrivateCloud returns a boolean if a field has been set.

### GetCloudManagementAddress

`func (o *DeploymentDetails) GetCloudManagementAddress() string`

GetCloudManagementAddress returns the CloudManagementAddress field if non-nil, zero value otherwise.

### GetCloudManagementAddressOk

`func (o *DeploymentDetails) GetCloudManagementAddressOk() (*string, bool)`

GetCloudManagementAddressOk returns a tuple with the CloudManagementAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudManagementAddress

`func (o *DeploymentDetails) SetCloudManagementAddress(v string)`

SetCloudManagementAddress sets CloudManagementAddress field to given value.

### HasCloudManagementAddress

`func (o *DeploymentDetails) HasCloudManagementAddress() bool`

HasCloudManagementAddress returns a boolean if a field has been set.

### GetMinimumIops

`func (o *DeploymentDetails) GetMinimumIops() int64`

GetMinimumIops returns the MinimumIops field if non-nil, zero value otherwise.

### GetMinimumIopsOk

`func (o *DeploymentDetails) GetMinimumIopsOk() (*int64, bool)`

GetMinimumIopsOk returns a tuple with the MinimumIops field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinimumIops

`func (o *DeploymentDetails) SetMinimumIops(v int64)`

SetMinimumIops sets MinimumIops field to given value.

### HasMinimumIops

`func (o *DeploymentDetails) HasMinimumIops() bool`

HasMinimumIops returns a boolean if a field has been set.

### GetMinimumCapacity

`func (o *DeploymentDetails) GetMinimumCapacity() int64`

GetMinimumCapacity returns the MinimumCapacity field if non-nil, zero value otherwise.

### GetMinimumCapacityOk

`func (o *DeploymentDetails) GetMinimumCapacityOk() (*int64, bool)`

GetMinimumCapacityOk returns a tuple with the MinimumCapacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinimumCapacity

`func (o *DeploymentDetails) SetMinimumCapacity(v int64)`

SetMinimumCapacity sets MinimumCapacity field to given value.

### HasMinimumCapacity

`func (o *DeploymentDetails) HasMinimumCapacity() bool`

HasMinimumCapacity returns a boolean if a field has been set.

### GetTierType

`func (o *DeploymentDetails) GetTierType() string`

GetTierType returns the TierType field if non-nil, zero value otherwise.

### GetTierTypeOk

`func (o *DeploymentDetails) GetTierTypeOk() (*string, bool)`

GetTierTypeOk returns a tuple with the TierType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTierType

`func (o *DeploymentDetails) SetTierType(v string)`

SetTierType sets TierType field to given value.

### HasTierType

`func (o *DeploymentDetails) HasTierType() bool`

HasTierType returns a boolean if a field has been set.

### GetSiteName

`func (o *DeploymentDetails) GetSiteName() string`

GetSiteName returns the SiteName field if non-nil, zero value otherwise.

### GetSiteNameOk

`func (o *DeploymentDetails) GetSiteNameOk() (*string, bool)`

GetSiteNameOk returns a tuple with the SiteName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSiteName

`func (o *DeploymentDetails) SetSiteName(v string)`

SetSiteName sets SiteName field to given value.

### HasSiteName

`func (o *DeploymentDetails) HasSiteName() bool`

HasSiteName returns a boolean if a field has been set.

### GetLocation

`func (o *DeploymentDetails) GetLocation() string`

GetLocation returns the Location field if non-nil, zero value otherwise.

### GetLocationOk

`func (o *DeploymentDetails) GetLocationOk() (*string, bool)`

GetLocationOk returns a tuple with the Location field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocation

`func (o *DeploymentDetails) SetLocation(v string)`

SetLocation sets Location field to given value.

### HasLocation

`func (o *DeploymentDetails) HasLocation() bool`

HasLocation returns a boolean if a field has been set.

### GetCountry

`func (o *DeploymentDetails) GetCountry() string`

GetCountry returns the Country field if non-nil, zero value otherwise.

### GetCountryOk

`func (o *DeploymentDetails) GetCountryOk() (*string, bool)`

GetCountryOk returns a tuple with the Country field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCountry

`func (o *DeploymentDetails) SetCountry(v string)`

SetCountry sets Country field to given value.

### HasCountry

`func (o *DeploymentDetails) HasCountry() bool`

HasCountry returns a boolean if a field has been set.

### GetState

`func (o *DeploymentDetails) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *DeploymentDetails) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *DeploymentDetails) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *DeploymentDetails) HasState() bool`

HasState returns a boolean if a field has been set.

### GetCity

`func (o *DeploymentDetails) GetCity() string`

GetCity returns the City field if non-nil, zero value otherwise.

### GetCityOk

`func (o *DeploymentDetails) GetCityOk() (*string, bool)`

GetCityOk returns a tuple with the City field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCity

`func (o *DeploymentDetails) SetCity(v string)`

SetCity sets City field to given value.

### HasCity

`func (o *DeploymentDetails) HasCity() bool`

HasCity returns a boolean if a field has been set.

### GetStreetAddress1

`func (o *DeploymentDetails) GetStreetAddress1() string`

GetStreetAddress1 returns the StreetAddress1 field if non-nil, zero value otherwise.

### GetStreetAddress1Ok

`func (o *DeploymentDetails) GetStreetAddress1Ok() (*string, bool)`

GetStreetAddress1Ok returns a tuple with the StreetAddress1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStreetAddress1

`func (o *DeploymentDetails) SetStreetAddress1(v string)`

SetStreetAddress1 sets StreetAddress1 field to given value.

### HasStreetAddress1

`func (o *DeploymentDetails) HasStreetAddress1() bool`

HasStreetAddress1 returns a boolean if a field has been set.

### GetStreetAddress2

`func (o *DeploymentDetails) GetStreetAddress2() string`

GetStreetAddress2 returns the StreetAddress2 field if non-nil, zero value otherwise.

### GetStreetAddress2Ok

`func (o *DeploymentDetails) GetStreetAddress2Ok() (*string, bool)`

GetStreetAddress2Ok returns a tuple with the StreetAddress2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStreetAddress2

`func (o *DeploymentDetails) SetStreetAddress2(v string)`

SetStreetAddress2 sets StreetAddress2 field to given value.

### HasStreetAddress2

`func (o *DeploymentDetails) HasStreetAddress2() bool`

HasStreetAddress2 returns a boolean if a field has been set.

### GetZipCode

`func (o *DeploymentDetails) GetZipCode() string`

GetZipCode returns the ZipCode field if non-nil, zero value otherwise.

### GetZipCodeOk

`func (o *DeploymentDetails) GetZipCodeOk() (*string, bool)`

GetZipCodeOk returns a tuple with the ZipCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZipCode

`func (o *DeploymentDetails) SetZipCode(v string)`

SetZipCode sets ZipCode field to given value.

### HasZipCode

`func (o *DeploymentDetails) HasZipCode() bool`

HasZipCode returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


