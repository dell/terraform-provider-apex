# UpdateMobilityTargetInput

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** | Updated name of the mobility group | [optional] 
**Description** | Pointer to **string** | Updated description of the mobility group | [optional] 
**BandwidthLimit** | Pointer to **int32** | Bandwidth limit in Mbps (Mega bits per second). | [optional] 
**Members** | Pointer to **[]string** | File members (Base64 encoded file paths) to use for file mobility operations, replaces all existing members if provided. | [optional] 
**AddMembers** | Pointer to **[]string** | File members (Base64 encoded file paths) to add to the existing list of members | [optional] 
**RemoveMembers** | Pointer to **[]string** | File members (Base64 encoded file paths) to remove from the existing list of members | [optional] 

## Methods

### NewUpdateMobilityTargetInput

`func NewUpdateMobilityTargetInput() *UpdateMobilityTargetInput`

NewUpdateMobilityTargetInput instantiates a new UpdateMobilityTargetInput object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewUpdateMobilityTargetInputWithDefaults

`func NewUpdateMobilityTargetInputWithDefaults() *UpdateMobilityTargetInput`

NewUpdateMobilityTargetInputWithDefaults instantiates a new UpdateMobilityTargetInput object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *UpdateMobilityTargetInput) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *UpdateMobilityTargetInput) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *UpdateMobilityTargetInput) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *UpdateMobilityTargetInput) HasName() bool`

HasName returns a boolean if a field has been set.

### GetDescription

`func (o *UpdateMobilityTargetInput) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *UpdateMobilityTargetInput) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *UpdateMobilityTargetInput) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *UpdateMobilityTargetInput) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetBandwidthLimit

`func (o *UpdateMobilityTargetInput) GetBandwidthLimit() int32`

GetBandwidthLimit returns the BandwidthLimit field if non-nil, zero value otherwise.

### GetBandwidthLimitOk

`func (o *UpdateMobilityTargetInput) GetBandwidthLimitOk() (*int32, bool)`

GetBandwidthLimitOk returns a tuple with the BandwidthLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBandwidthLimit

`func (o *UpdateMobilityTargetInput) SetBandwidthLimit(v int32)`

SetBandwidthLimit sets BandwidthLimit field to given value.

### HasBandwidthLimit

`func (o *UpdateMobilityTargetInput) HasBandwidthLimit() bool`

HasBandwidthLimit returns a boolean if a field has been set.

### GetMembers

`func (o *UpdateMobilityTargetInput) GetMembers() []string`

GetMembers returns the Members field if non-nil, zero value otherwise.

### GetMembersOk

`func (o *UpdateMobilityTargetInput) GetMembersOk() (*[]string, bool)`

GetMembersOk returns a tuple with the Members field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMembers

`func (o *UpdateMobilityTargetInput) SetMembers(v []string)`

SetMembers sets Members field to given value.

### HasMembers

`func (o *UpdateMobilityTargetInput) HasMembers() bool`

HasMembers returns a boolean if a field has been set.

### GetAddMembers

`func (o *UpdateMobilityTargetInput) GetAddMembers() []string`

GetAddMembers returns the AddMembers field if non-nil, zero value otherwise.

### GetAddMembersOk

`func (o *UpdateMobilityTargetInput) GetAddMembersOk() (*[]string, bool)`

GetAddMembersOk returns a tuple with the AddMembers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddMembers

`func (o *UpdateMobilityTargetInput) SetAddMembers(v []string)`

SetAddMembers sets AddMembers field to given value.

### HasAddMembers

`func (o *UpdateMobilityTargetInput) HasAddMembers() bool`

HasAddMembers returns a boolean if a field has been set.

### GetRemoveMembers

`func (o *UpdateMobilityTargetInput) GetRemoveMembers() []string`

GetRemoveMembers returns the RemoveMembers field if non-nil, zero value otherwise.

### GetRemoveMembersOk

`func (o *UpdateMobilityTargetInput) GetRemoveMembersOk() (*[]string, bool)`

GetRemoveMembersOk returns a tuple with the RemoveMembers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveMembers

`func (o *UpdateMobilityTargetInput) SetRemoveMembers(v []string)`

SetRemoveMembers sets RemoveMembers field to given value.

### HasRemoveMembers

`func (o *UpdateMobilityTargetInput) HasRemoveMembers() bool`

HasRemoveMembers returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


