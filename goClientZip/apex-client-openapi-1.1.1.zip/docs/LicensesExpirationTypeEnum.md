# LicensesExpirationTypeEnum

## Enum


* `TRIAL` (value: `"TRIAL"`)

* `EXT_TRIAL` (value: `"EXT_TRIAL"`)

* `TIME_LIMITED` (value: `"TIME_LIMITED"`)

* `GRACE_PERIOD` (value: `"GRACE_PERIOD"`)

* `RESTRICTED` (value: `"RESTRICTED"`)

* `PERMANENT` (value: `"PERMANENT"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


