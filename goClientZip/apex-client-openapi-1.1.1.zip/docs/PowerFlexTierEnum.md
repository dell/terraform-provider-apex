# PowerFlexTierEnum

## Enum


* `BALANCED` (value: `"BALANCED"`)

* `PERFORMANCE_OPTIMIZED` (value: `"PERFORMANCE_OPTIMIZED"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


