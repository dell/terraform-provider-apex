# StorageSystemsRegisterTrustPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InitialAccessToken** | **string** | Initial access token for establishing the trust between an on-prem storage system and APEX Navigator for Multicloud Storage. For PowerScale this access token follows the format &#39;isisessid:isicsrf&#39; where &#39;isisessid&#39; and &#39;isicsrf&#39; are cookies obtained via the PowerScale login API  | 
**SystemType** | [**StorageProductEnum**](StorageProductEnum.md) |  | 

## Methods

### NewStorageSystemsRegisterTrustPostRequest

`func NewStorageSystemsRegisterTrustPostRequest(initialAccessToken string, systemType StorageProductEnum, ) *StorageSystemsRegisterTrustPostRequest`

NewStorageSystemsRegisterTrustPostRequest instantiates a new StorageSystemsRegisterTrustPostRequest object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewStorageSystemsRegisterTrustPostRequestWithDefaults

`func NewStorageSystemsRegisterTrustPostRequestWithDefaults() *StorageSystemsRegisterTrustPostRequest`

NewStorageSystemsRegisterTrustPostRequestWithDefaults instantiates a new StorageSystemsRegisterTrustPostRequest object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInitialAccessToken

`func (o *StorageSystemsRegisterTrustPostRequest) GetInitialAccessToken() string`

GetInitialAccessToken returns the InitialAccessToken field if non-nil, zero value otherwise.

### GetInitialAccessTokenOk

`func (o *StorageSystemsRegisterTrustPostRequest) GetInitialAccessTokenOk() (*string, bool)`

GetInitialAccessTokenOk returns a tuple with the InitialAccessToken field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInitialAccessToken

`func (o *StorageSystemsRegisterTrustPostRequest) SetInitialAccessToken(v string)`

SetInitialAccessToken sets InitialAccessToken field to given value.


### GetSystemType

`func (o *StorageSystemsRegisterTrustPostRequest) GetSystemType() StorageProductEnum`

GetSystemType returns the SystemType field if non-nil, zero value otherwise.

### GetSystemTypeOk

`func (o *StorageSystemsRegisterTrustPostRequest) GetSystemTypeOk() (*StorageProductEnum, bool)`

GetSystemTypeOk returns a tuple with the SystemType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemType

`func (o *StorageSystemsRegisterTrustPostRequest) SetSystemType(v StorageProductEnum)`

SetSystemType sets SystemType field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


