# UnmapInput

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HostMappings** | Pointer to **[]string** | The list of host mapping ids of hosts to be unmapped.host_mappings and host_ids are mutually exclusive. | [optional] 
**HostIds** | Pointer to **[]string** | The list of host ids of hosts to be unmapped.host_mappings and host_ids are mutually exclusive. host id can be retrieved using collection query GET /rest/services/storage/v1/hosts. | [optional] 

## Methods

### NewUnmapInput

`func NewUnmapInput() *UnmapInput`

NewUnmapInput instantiates a new UnmapInput object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewUnmapInputWithDefaults

`func NewUnmapInputWithDefaults() *UnmapInput`

NewUnmapInputWithDefaults instantiates a new UnmapInput object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHostMappings

`func (o *UnmapInput) GetHostMappings() []string`

GetHostMappings returns the HostMappings field if non-nil, zero value otherwise.

### GetHostMappingsOk

`func (o *UnmapInput) GetHostMappingsOk() (*[]string, bool)`

GetHostMappingsOk returns a tuple with the HostMappings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostMappings

`func (o *UnmapInput) SetHostMappings(v []string)`

SetHostMappings sets HostMappings field to given value.

### HasHostMappings

`func (o *UnmapInput) HasHostMappings() bool`

HasHostMappings returns a boolean if a field has been set.

### GetHostIds

`func (o *UnmapInput) GetHostIds() []string`

GetHostIds returns the HostIds field if non-nil, zero value otherwise.

### GetHostIdsOk

`func (o *UnmapInput) GetHostIdsOk() (*[]string, bool)`

GetHostIdsOk returns a tuple with the HostIds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostIds

`func (o *UnmapInput) SetHostIds(v []string)`

SetHostIds sets HostIds field to given value.

### HasHostIds

`func (o *UnmapInput) HasHostIds() bool`

HasHostIds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


