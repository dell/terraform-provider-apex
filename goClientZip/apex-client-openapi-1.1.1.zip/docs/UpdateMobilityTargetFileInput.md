# UpdateMobilityTargetFileInput

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** | Updated name of the mobility group | [optional] 
**Description** | Pointer to **string** | Updated description of the mobility group | [optional] 
**Members** | Pointer to **[]string** | File members (Base64 encoded file paths) to use for file mobility operations, replaces all existing members if provided. | [optional] 
**AddMembers** | Pointer to **[]string** | File members (Base64 encoded file paths) to add to the existing list of members | [optional] 
**RemoveMembers** | Pointer to **[]string** | File members (Base64 encoded file paths) to remove from the existing list of members | [optional] 

## Methods

### NewUpdateMobilityTargetFileInput

`func NewUpdateMobilityTargetFileInput() *UpdateMobilityTargetFileInput`

NewUpdateMobilityTargetFileInput instantiates a new UpdateMobilityTargetFileInput object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewUpdateMobilityTargetFileInputWithDefaults

`func NewUpdateMobilityTargetFileInputWithDefaults() *UpdateMobilityTargetFileInput`

NewUpdateMobilityTargetFileInputWithDefaults instantiates a new UpdateMobilityTargetFileInput object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *UpdateMobilityTargetFileInput) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *UpdateMobilityTargetFileInput) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *UpdateMobilityTargetFileInput) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *UpdateMobilityTargetFileInput) HasName() bool`

HasName returns a boolean if a field has been set.

### GetDescription

`func (o *UpdateMobilityTargetFileInput) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *UpdateMobilityTargetFileInput) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *UpdateMobilityTargetFileInput) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *UpdateMobilityTargetFileInput) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetMembers

`func (o *UpdateMobilityTargetFileInput) GetMembers() []string`

GetMembers returns the Members field if non-nil, zero value otherwise.

### GetMembersOk

`func (o *UpdateMobilityTargetFileInput) GetMembersOk() (*[]string, bool)`

GetMembersOk returns a tuple with the Members field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMembers

`func (o *UpdateMobilityTargetFileInput) SetMembers(v []string)`

SetMembers sets Members field to given value.

### HasMembers

`func (o *UpdateMobilityTargetFileInput) HasMembers() bool`

HasMembers returns a boolean if a field has been set.

### GetAddMembers

`func (o *UpdateMobilityTargetFileInput) GetAddMembers() []string`

GetAddMembers returns the AddMembers field if non-nil, zero value otherwise.

### GetAddMembersOk

`func (o *UpdateMobilityTargetFileInput) GetAddMembersOk() (*[]string, bool)`

GetAddMembersOk returns a tuple with the AddMembers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddMembers

`func (o *UpdateMobilityTargetFileInput) SetAddMembers(v []string)`

SetAddMembers sets AddMembers field to given value.

### HasAddMembers

`func (o *UpdateMobilityTargetFileInput) HasAddMembers() bool`

HasAddMembers returns a boolean if a field has been set.

### GetRemoveMembers

`func (o *UpdateMobilityTargetFileInput) GetRemoveMembers() []string`

GetRemoveMembers returns the RemoveMembers field if non-nil, zero value otherwise.

### GetRemoveMembersOk

`func (o *UpdateMobilityTargetFileInput) GetRemoveMembersOk() (*[]string, bool)`

GetRemoveMembersOk returns a tuple with the RemoveMembers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoveMembers

`func (o *UpdateMobilityTargetFileInput) SetRemoveMembers(v []string)`

SetRemoveMembers sets RemoveMembers field to given value.

### HasRemoveMembers

`func (o *UpdateMobilityTargetFileInput) HasRemoveMembers() bool`

HasRemoveMembers returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


