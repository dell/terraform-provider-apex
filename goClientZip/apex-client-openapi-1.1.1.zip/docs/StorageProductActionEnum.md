# StorageProductActionEnum

## Enum


* `DELETE` (value: `"DELETE"`)

* `CREATE` (value: `"CREATE"`)

* `DEPLOY` (value: `"DEPLOY"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


