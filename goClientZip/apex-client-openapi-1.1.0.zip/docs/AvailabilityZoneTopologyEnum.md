# AvailabilityZoneTopologyEnum

## Enum


* `SINGLE_AVAILABILITY_ZONE` (value: `"SINGLE_AVAILABILITY_ZONE"`)

* `MULTIPLE_AVAILABILITY_ZONE` (value: `"MULTIPLE_AVAILABILITY_ZONE"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


