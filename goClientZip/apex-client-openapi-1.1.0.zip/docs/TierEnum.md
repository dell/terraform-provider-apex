# TierEnum

## Enum


* `BALANCED` (value: `"BALANCED"`)

* `PERFORMANCE_OPTIMIZED` (value: `"PERFORMANCE_OPTIMIZED"`)

* `COST_OPTIMIZED` (value: `"COST_OPTIMIZED"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


