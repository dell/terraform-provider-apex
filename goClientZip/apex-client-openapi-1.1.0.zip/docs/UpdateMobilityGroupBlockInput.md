# UpdateMobilityGroupBlockInput

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | Pointer to **string** | Updated name of the mobility group | [optional] 
**Description** | Pointer to **string** | Updated description of the mobility group | [optional] 
**Members** | Pointer to **[]string** | Update the list of members (e.g. volumes).  This is the list of identifiers of members for the mobility group.  It will replace the current list of members. | [optional] 

## Methods

### NewUpdateMobilityGroupBlockInput

`func NewUpdateMobilityGroupBlockInput() *UpdateMobilityGroupBlockInput`

NewUpdateMobilityGroupBlockInput instantiates a new UpdateMobilityGroupBlockInput object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewUpdateMobilityGroupBlockInputWithDefaults

`func NewUpdateMobilityGroupBlockInputWithDefaults() *UpdateMobilityGroupBlockInput`

NewUpdateMobilityGroupBlockInputWithDefaults instantiates a new UpdateMobilityGroupBlockInput object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetName

`func (o *UpdateMobilityGroupBlockInput) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *UpdateMobilityGroupBlockInput) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *UpdateMobilityGroupBlockInput) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *UpdateMobilityGroupBlockInput) HasName() bool`

HasName returns a boolean if a field has been set.

### GetDescription

`func (o *UpdateMobilityGroupBlockInput) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *UpdateMobilityGroupBlockInput) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *UpdateMobilityGroupBlockInput) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *UpdateMobilityGroupBlockInput) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetMembers

`func (o *UpdateMobilityGroupBlockInput) GetMembers() []string`

GetMembers returns the Members field if non-nil, zero value otherwise.

### GetMembersOk

`func (o *UpdateMobilityGroupBlockInput) GetMembersOk() (*[]string, bool)`

GetMembersOk returns a tuple with the Members field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMembers

`func (o *UpdateMobilityGroupBlockInput) SetMembers(v []string)`

SetMembers sets Members field to given value.

### HasMembers

`func (o *UpdateMobilityGroupBlockInput) HasMembers() bool`

HasMembers returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


