# AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StringLike** | Pointer to [**AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike**](AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike.md) |  | [optional] 

## Methods

### NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition

`func NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition() *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition`

NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition instantiates a new AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionWithDefaults

`func NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionWithDefaults() *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition`

NewAwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionWithDefaults instantiates a new AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetStringLike

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition) GetStringLike() AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike`

GetStringLike returns the StringLike field if non-nil, zero value otherwise.

### GetStringLikeOk

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition) GetStringLikeOk() (*AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike, bool)`

GetStringLikeOk returns a tuple with the StringLike field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStringLike

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition) SetStringLike(v AwsPermissionPoliciesInstancePermissionPolicyStatementInnerConditionStringLike)`

SetStringLike sets StringLike field to given value.

### HasStringLike

`func (o *AwsPermissionPoliciesInstancePermissionPolicyStatementInnerCondition) HasStringLike() bool`

HasStringLike returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


