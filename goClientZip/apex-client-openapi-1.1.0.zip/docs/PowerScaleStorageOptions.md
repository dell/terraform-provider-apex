# PowerScaleStorageOptions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SystemType** | **string** | Type of the Dell APEX storage system to be deployed. | 
**Version** | Pointer to **string** | Storage product version to deploy | [optional] 
**Tier** | Pointer to [**PowerScaleTierEnum**](PowerScaleTierEnum.md) |  | [optional] 
**RawCapacity** | Pointer to **string** | This is applicable only for APEX File Storage. Raw storage capacity is represented in bytes. | [optional] 
**SmartconnectFqdn** | Pointer to **string** | This is applicable only for APEX File Storage. The SmartConnect hostname FQDN that APEX Navigator uses to configure SmartConnect cluster hostname (zone name) in APEX File Storage. This hostname is used to access the cluster from clients and provides transparent load-balancing and advanced failover. See APEX Navigator for Multicloud Storage documentation for additional steps required to configure the hostname resolution in your DNS. | [optional] 

## Methods

### NewPowerScaleStorageOptions

`func NewPowerScaleStorageOptions(systemType string, ) *PowerScaleStorageOptions`

NewPowerScaleStorageOptions instantiates a new PowerScaleStorageOptions object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewPowerScaleStorageOptionsWithDefaults

`func NewPowerScaleStorageOptionsWithDefaults() *PowerScaleStorageOptions`

NewPowerScaleStorageOptionsWithDefaults instantiates a new PowerScaleStorageOptions object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSystemType

`func (o *PowerScaleStorageOptions) GetSystemType() string`

GetSystemType returns the SystemType field if non-nil, zero value otherwise.

### GetSystemTypeOk

`func (o *PowerScaleStorageOptions) GetSystemTypeOk() (*string, bool)`

GetSystemTypeOk returns a tuple with the SystemType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemType

`func (o *PowerScaleStorageOptions) SetSystemType(v string)`

SetSystemType sets SystemType field to given value.


### GetVersion

`func (o *PowerScaleStorageOptions) GetVersion() string`

GetVersion returns the Version field if non-nil, zero value otherwise.

### GetVersionOk

`func (o *PowerScaleStorageOptions) GetVersionOk() (*string, bool)`

GetVersionOk returns a tuple with the Version field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVersion

`func (o *PowerScaleStorageOptions) SetVersion(v string)`

SetVersion sets Version field to given value.

### HasVersion

`func (o *PowerScaleStorageOptions) HasVersion() bool`

HasVersion returns a boolean if a field has been set.

### GetTier

`func (o *PowerScaleStorageOptions) GetTier() PowerScaleTierEnum`

GetTier returns the Tier field if non-nil, zero value otherwise.

### GetTierOk

`func (o *PowerScaleStorageOptions) GetTierOk() (*PowerScaleTierEnum, bool)`

GetTierOk returns a tuple with the Tier field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTier

`func (o *PowerScaleStorageOptions) SetTier(v PowerScaleTierEnum)`

SetTier sets Tier field to given value.

### HasTier

`func (o *PowerScaleStorageOptions) HasTier() bool`

HasTier returns a boolean if a field has been set.

### GetRawCapacity

`func (o *PowerScaleStorageOptions) GetRawCapacity() string`

GetRawCapacity returns the RawCapacity field if non-nil, zero value otherwise.

### GetRawCapacityOk

`func (o *PowerScaleStorageOptions) GetRawCapacityOk() (*string, bool)`

GetRawCapacityOk returns a tuple with the RawCapacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRawCapacity

`func (o *PowerScaleStorageOptions) SetRawCapacity(v string)`

SetRawCapacity sets RawCapacity field to given value.

### HasRawCapacity

`func (o *PowerScaleStorageOptions) HasRawCapacity() bool`

HasRawCapacity returns a boolean if a field has been set.

### GetSmartconnectFqdn

`func (o *PowerScaleStorageOptions) GetSmartconnectFqdn() string`

GetSmartconnectFqdn returns the SmartconnectFqdn field if non-nil, zero value otherwise.

### GetSmartconnectFqdnOk

`func (o *PowerScaleStorageOptions) GetSmartconnectFqdnOk() (*string, bool)`

GetSmartconnectFqdnOk returns a tuple with the SmartconnectFqdn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmartconnectFqdn

`func (o *PowerScaleStorageOptions) SetSmartconnectFqdn(v string)`

SetSmartconnectFqdn sets SmartconnectFqdn field to given value.

### HasSmartconnectFqdn

`func (o *PowerScaleStorageOptions) HasSmartconnectFqdn() bool`

HasSmartconnectFqdn returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


